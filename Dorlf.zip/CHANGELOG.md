# 0.1.2

Changed the order of a couple of traits.

Updated trait wording.

Nerfed Ironworks to proc an additional time for every 3 Taunt rather than every 2.

Nerfed Iron Shield to give 0.1% Resist/Charge

Reduced charges on Plasma Beam

# 0.1.1

Updated Icon

# 0.1.0

Initial concept
